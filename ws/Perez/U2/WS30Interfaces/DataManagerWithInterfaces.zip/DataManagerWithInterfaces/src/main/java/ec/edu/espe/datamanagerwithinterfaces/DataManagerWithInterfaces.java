/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espe.datamanagerwithinterfaces;

/**
 *
 * @author Carlos Perez,The Javas, DCCO-ESPE
 */
public class DataManagerWithInterfaces {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
