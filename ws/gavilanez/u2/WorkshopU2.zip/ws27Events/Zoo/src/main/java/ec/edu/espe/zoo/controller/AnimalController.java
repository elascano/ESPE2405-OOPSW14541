/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.zoo.controller;

import ec.edu.espe.zoo.model.Animal;
/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class AnimalController {
    public static boolean create(Animal animal) {
        System.out.println("calling the mehtod to save");
        return true;
    }
}
