/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espe.datamanagerwithinterfaces;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class DatamanagerWithInterfaces {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
