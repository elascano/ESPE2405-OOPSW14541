/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.complexoperation.view;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class OperationPrinting {

    static void printAdditon(float addend1, float addend2, float sum) {
        System.out.println("The additing of " + addend1 + " + " + addend2 + " ---> " + sum);
    }
    
}
