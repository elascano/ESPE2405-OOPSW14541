/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ed.edu.espe.zoo.controller;

import ec.edu.espe.zoo.model.Animal;

/**
 *
 * @author Brayan Gualotuña, Dev Dynasty, DCCO-ESPE
 */
public class AnimalController {
    
    public static boolean create(Animal animal){
        
        //TODO call the utils method to save this information in the cloud
        
        
        
        System.out.println("Calling the method to save");
        
        return true;
    }
    
}
