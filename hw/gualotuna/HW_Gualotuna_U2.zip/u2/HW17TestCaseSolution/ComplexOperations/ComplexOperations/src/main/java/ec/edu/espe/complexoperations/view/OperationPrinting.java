
package ec.edu.espe.complexoperations.view;


/**
 *
 * @author Brayan Gualotuña, Dev Dynasty, DCCO-ESPE
 *
 */
public class OperationPrinting {

    public static void printAddition(float addend1, float addend2, float sum) {
        System.out.println("The addition of " + addend1 + "+" + addend2 + "=" + sum);
    }

}
