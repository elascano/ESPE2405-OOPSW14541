
module.exports = {
    printAddition: function (addend1, addend2, sum) {
        console.log(`The addition of ${addend1} + ${addend2} = ${sum}`);
    }
};
