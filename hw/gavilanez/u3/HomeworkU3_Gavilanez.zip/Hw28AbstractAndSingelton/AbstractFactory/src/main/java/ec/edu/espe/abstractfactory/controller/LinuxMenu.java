
package ec.edu.espe.abstractfactory.controller;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class LinuxMenu extends Menu{
    public void paint(){
        System.out.println("I'm a LinuxMenu: " + caption);
    }
}
