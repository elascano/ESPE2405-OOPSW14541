
package ec.edu.espe.abstractfactory.controller;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class WinMenu extends Menu{
    public void paint(){
        System.out.println("I'm a WinMenu: " + caption);
    }
}
