
package ec.edu.espe.observerpattern.controller;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public interface IInvestor {
    void update(Stock stock,Object args);
}

