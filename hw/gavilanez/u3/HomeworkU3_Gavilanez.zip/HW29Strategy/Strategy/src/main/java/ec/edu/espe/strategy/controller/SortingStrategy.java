
package ec.edu.espe.strategy.controller;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public abstract class SortingStrategy {
    public abstract void sort(int[] array);
}
