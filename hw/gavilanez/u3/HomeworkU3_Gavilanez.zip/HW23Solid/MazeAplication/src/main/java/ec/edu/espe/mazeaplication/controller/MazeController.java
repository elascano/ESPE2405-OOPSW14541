
package ec.edu.espe.mazeaplication.controller;

import ec.edu.espe.mazeaplication.model.Maze;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class MazeController {
    public Maze generateMaze() {
        return new Maze();
    }

    public void saveMazeAsImage(Maze maze) {
    }
}
