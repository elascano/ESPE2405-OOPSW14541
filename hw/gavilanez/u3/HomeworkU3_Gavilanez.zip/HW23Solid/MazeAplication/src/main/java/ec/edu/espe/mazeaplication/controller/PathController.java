/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.mazeaplication.controller;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class PathController implements PathGenerator {
    @Override
    public void findPathRoute() {
        // Lógica para encontrar la ruta de la solución
    }

    @Override
    public void validatePath() {
        // Lógica para validar la ruta de la solución
    }
}
