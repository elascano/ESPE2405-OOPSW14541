/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.mazeaplication.controller;

import ec.edu.espe.mazeaplication.model.Room;

/**
 *
 * @author Kenny Gavilanez, Dev Dynasty, DCCO-ESPE
 */
public class RoomController {
    public Room generateRoom() {
        // Lógica para generar una habitación
        return new Room();
    }

    public boolean validationRoom(Room room) {
        // Lógica para validar una habitación
        return true;
    }
}
