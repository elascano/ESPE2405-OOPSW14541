/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exam3851;

import java.util.List;

/**
 *
 * @author G406
 */
public class A {
    private List<A> aList;
    private List<B> bList;
    private List<C> cList;
    private List<D> dList;
    
    

    /**
     * @return the aList
     */
    public List<A> getaList() {
        return aList;
    }

    /**
     * @param aList the aList to set
     */
    public void setaList(List<A> aList) {
        this.aList = aList;
    }

    /**
     * @return the bList
     */
    public List<B> getbList() {
        return bList;
    }

    /**
     * @param bList the bList to set
     */
    public void setbList(List<B> bList) {
        this.bList = bList;
    }

    /**
     * @return the cList
     */
    public List<C> getcList() {
        return cList;
    }

    /**
     * @param cList the cList to set
     */
    public void setcList(List<C> cList) {
        this.cList = cList;
    }

    /**
     * @return the dList
     */
    public List<D> getdList() {
        return dList;
    }

    /**
     * @param dList the dList to set
     */
    public void setdList(List<D> dList) {
        this.dList = dList;
    }
    
    
}
