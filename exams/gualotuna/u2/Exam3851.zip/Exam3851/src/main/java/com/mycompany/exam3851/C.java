/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exam3851;

import java.util.List;

/**
 *
 * @author G406
 */
public class C extends A{
    private List<E> eList;

    /**
     * @return the eList
     */
    public List<E> geteList() {
        return eList;
    }

    /**
     * @param eList the eList to set
     */
    public void seteList(List<E> eList) {
        this.eList = eList;
    }
    
}
