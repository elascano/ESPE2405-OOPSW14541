/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exam3851;

import java.util.List;

/**
 *
 * @author G406
 */
public class D extends A{
    private List<F> fList;

    /**
     * @return the fList
     */
    public List<F> getfList() {
        return fList;
    }

    /**
     * @param fList the fList to set
     */
    public void setfList(List<F> fList) {
        this.fList = fList;
    }
}
