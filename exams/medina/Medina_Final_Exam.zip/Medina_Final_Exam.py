from abc import ABC, abstractmethod
from pymongo import MongoClient
from javax.swing import JOptionPane
import sys

# Clases de estrategia de ordenamiento
class SortingStrategy(ABC):
    @abstractmethod
    def sort(self, data):
        pass

class BubbleSort(SortingStrategy):
    def sort(self, data):
        n = len(data)
        for i in range(n):
            for j in range(0, n-i-1):
                if data[j] > data[j+1]:
                    data[j], data[j+1] = data[j+1], data[j]
        return data

class QuickSort(SortingStrategy):
    def sort(self, data):
        if len(data) <= 1:
            return data
        pivot = data[len(data) // 2]
        left = [x for x in data if x < pivot]
        middle = [x for x in data if x == pivot]
        right = [x for x in data if x > pivot]
        return self.sort(left) + middle + self.sort(right)

class InsertionSort(SortingStrategy):
    def sort(self, data):
        for i in range(1, len(data)):
            key = data[i]
            j = i - 1
            while j >= 0 and key < data[j]:
                data[j + 1] = data[j]
                j -= 1
            data[j + 1] = key
        return data

# Contexto de ordenamiento que selecciona la estrategia
class SortingContext:
    def __init__(self):
        self._strategy = None

    def set_sort_strategy(self, strategy):
        self._strategy = strategy

    def sort(self, data):
        if self._strategy is None:
            raise ValueError("No sorting strategy set")
        return self._strategy.sort(data)

# Función principal para la interfaz gráfica y la lógica del programa
def main():
    # Crear la conexión a la base de datos MongoDB
    client = MongoClient("mongodb+srv://<username>:<password>@cluster0.mongodb.net/?retryWrites=true&w=majority")
    db = client.strategyMedina
    collection = db.arrayNathaly

    # Pedir al usuario que ingrese la lista de números
    input_data = JOptionPane.showInputDialog(None, "Ingrese los elementos a ordenar separados por comas:")
    
    if input_data is None:  # Si el usuario cancela, salir del programa
        sys.exit(0)
    
    try:
        # Convertir la cadena de entrada en una lista de números
        data = [int(x.strip()) for x in input_data.split(",")]
    except ValueError:
        JOptionPane.showMessageDialog(None, "Por favor, ingrese solo números separados por comas.", "Error", JOptionPane.ERROR_MESSAGE)
        sys.exit(1)

    # Validar el tamaño de la lista
    size = len(data)
    if size <= 1:
        JOptionPane.showMessageDialog(None, "El arreglo debe tener más de un elemento.", "Error", JOptionPane.ERROR_MESSAGE)
        sys.exit(1)

    # Seleccionar la estrategia de ordenamiento adecuada
    context = SortingContext()
    if 2 <= size <= 5:
        context.set_sort_strategy(BubbleSort())
        algorithm = "BubbleSort"
    elif 6 <= size <= 10:
        context.set_sort_strategy(InsertionSort())
        algorithm = "InsertionSort"
    else:
        context.set_sort_strategy(QuickSort())
        algorithm = "QuickSort"

    # Ordenar los datos
    sorted_data = context.sort(data)


    message = (f"Arreglo sin ordenar: {data}\n"
               f"Tamaño del arreglo: {size}\n"
               f"Algoritmo seleccionado: {algorithm}\n"
               f"Arreglo ordenado: {sorted_data}")
    JOptionPane.showMessageDialog(None, message)


    record = {
        "unsorted": ", ".join(map(str, data)),
        "size": size,
        "sort algorithm": algorithm,
        "sorted": ", ".join(map(str, sorted_data))
    }
    collection.insert_one(record)


    client.close()

if __name__ == "__main__":
    main()
