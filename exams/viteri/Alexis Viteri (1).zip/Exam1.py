import json
class SoccerBall(object):
    def __init__(self, _weight, _color, _diameter, _pressure, _id, _dateOfPurchase ):
        self.weight = _weight
        self.color = _color
        self.diameter = _diameter
        self.pressure = _pressure
        self.id = _id
        self.dateOfPurchase = _dateOfPurchase
class FileManager():
    def __init__(self):
        SoccerBall='{"weight": 2.1,"color": "Blue","diameter": 20,"pressure": 3.5,"id": 1,"dateOfPurchase": "20/4/2006"}'
        SOCCERBALL1={
            'weight' : 2.1,
            'color' : 'Blue',
            'diameter' : 20,
            'pressure' : 3.5,
            'id': 1,
            'dateOfPurchase': '20/4/2006'
        }
        SoccerBall_json=json.dumps(SOCCERBALL1)
        print(SoccerBall_json)
        print(type(SoccerBall_json))
        print(SoccerBall_json[2])
        print('\n\n')
        
        SoccerBall_json=json.dumps(SOCCERBALL1,indent=4,separators=(",",":"))
        print(SoccerBall_json)
        print(type(SoccerBall_json))
        print('\n\n')
        
        data_json=json.JSONEncoder().encode({'id':['1']})
        print(data_json)
        print(type(data_json))
        
        data_diccionario=json.JSONDecoder().decode(data_json)
        print(data_diccionario)
        print(type(data_diccionario))
        print('\n\n')
        
        class Json:
            def __init__(self,SoccerBall):
                self.SoccerBall=SoccerBall

        SoccerBall2 = Json('1')
        print(SoccerBall2)
        print(SoccerBall2.SoccerBall)
        SoccerBall_json=json.dumps(SoccerBall2.__dict__)
        print(SoccerBall_json)
        print(type(SoccerBall_json))
        SoccerBall_dict=json.loads(SoccerBall_json)
        print(SoccerBall_dict)
        print(type(SoccerBall_dict))
        print(SoccerBall_dict['carrera'])