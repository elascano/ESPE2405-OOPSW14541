class E {
    constructor() {
        this.a = new A();
        this.b = Array(10),fill(new B());
    }

    m2(z){

    }
}

module.export = E