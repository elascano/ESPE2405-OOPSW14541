class B {

}

module.export = B;
