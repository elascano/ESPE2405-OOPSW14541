import B from "./B.js";
class C {
    constructor() {
        this.b = new B();
    }
}

module.export = C