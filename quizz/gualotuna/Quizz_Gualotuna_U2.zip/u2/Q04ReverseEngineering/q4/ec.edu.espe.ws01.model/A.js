import B from "./B.js";
class A{
    constructor(){
        this.b1 = new B();
        this.b2 = new B();
    }
    m1(x, y){

    }
}

module.export = A;