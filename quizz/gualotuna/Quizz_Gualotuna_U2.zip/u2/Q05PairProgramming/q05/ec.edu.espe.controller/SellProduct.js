class SellProduct {
    static sell(id, inventory) {
        inventory.removeProduct(id);
    }
}
